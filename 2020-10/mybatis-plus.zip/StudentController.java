package org.yuye.management.controller;

import java.io.ObjectOutputStream.PutField;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.yuye.management.dao.StudentMapper;
import org.yuye.management.pojo.Student;
import org.yuye.management.pojo.Teacher;
import org.yuye.management.pojo.User;
import org.yuye.management.service.impl.StudentService;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.injector.methods.SelectPage;
import com.baomidou.mybatisplus.core.injector.methods.Update;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import net.sf.jsqlparser.expression.operators.relational.Between;



//@RestController注解将方法的返回值返回到页面上

@RestController
public class StudentController {

	@Resource
	StudentService studentService;
	
	

	//添加方法 返回的是执行成功的条数
	@RequestMapping("/hello") 
	public void add() { 
		Student student = new Student();
		
		student.setStuAge(10);
		student.setStuName("小明");
		studentService.add(student);
		System.out.println(student.getStuId());
	  
	  }
	 
	
	@RequestMapping("/delelebyid")
	public void deletebyId() {
		studentService.deletebyId(2);
	}

	
	//map里面放的是查询条件
	@RequestMapping("/deletebymap")
	public int deletebymap() {
		Map<String, Object> map = new HashMap<String, Object>();
		
		System.out.println(studentService.deletebymap(map));
		return studentService.deletebymap(map);

	}
	
	
	//* @param updatewrapper 增删改的类（可以为 null）	
	//between方法三个参数，分别是column、value1、value2，该方法表示column的值要在value1和value2之间；
	//eq是equals的简写，该方法两个参数，column和value，表示column的值和value要相等。
	//注意column是数据表对应的字段，而非实体类属性字段。
	
	@RequestMapping("/delete")
	public int delete() {
		UpdateWrapper<Student> qw = new UpdateWrapper<Student>();
		qw
			.eq("stu_name", "1")
			.between("stu_id", 1, 2);
		System.out.println(studentService.delete(qw));
		return studentService.delete(qw);
		
	}
	
	//根据id删除
	@RequestMapping("/updatebuid")
	public int updatebyid() {
		Student student = new Student();
		student.setStuId(2);
		
		student.setStuName("小芳");
		System.out.println(studentService.updateById(student));
		return studentService.updateById(student);
	}
	
	@RequestMapping("/update")
	public int update() {
		Student student = new Student();
		student.setStuId(3);
		student.setStuAge(2);
		//要查询的数据
		UpdateWrapper<Student> uw = new UpdateWrapper<Student>();
		uw
			.eq("stu_id", 2);
		System.out.println(studentService.update(student, uw));
		return 2;
			
	}
	
	@RequestMapping("/selectById")
	public Student selectById() {
		System.out.println(studentService.selectById(2));
		
		return studentService.selectById(2);
	}
	
	//根据多条id删除，List里面放的是你要删除的多条id
	@RequestMapping("/selectBatchIds")
	public List<Student> selectBatchIds(){
		List<Integer> idList = new ArrayList<Integer>();
		idList.add(2);
		idList.add(3);
		List<Student> list = studentService.selectBatchIds(idList);
		for (Student student :list) {
			System.out.println(student);
		}
		return list;
	}
	
	//如果map没有值就是全查询
	@RequestMapping("/selectByMap")
	public List<Student> selectByMap(){
		Map<String, Object> map = new HashMap<String, Object>();
		
		map.put("stu_name", "小芳");
		List<Student> list = studentService.selectByMap(map);
		for(Student student : list) {
			System.out.println(student);
		}
		return list;
	}
	
	//如果查询的数据有多条的话会报错
	//增删改的条件放在updateWrapper中，查的条件放在queryWrapper中
	@RequestMapping("/selectOne")
	public Student selectOne() {
		QueryWrapper<Student> qW = new QueryWrapper<Student>();
		qW
			.eq("stu_name", "小芳");
			
		System.out.println(studentService.selectOne(qW));
		return studentService.selectOne(qW);
				
	}
	
	//查询符合条件的数量
	@RequestMapping("/selectCount")
	public Integer selectCount() {
		QueryWrapper<Student> qw = new QueryWrapper<Student>();
		qw.
			eq("stu_name", "小芳");
		System.out.println(studentService.selectCount(qw));
		return studentService.selectCount(qw);
	}
	
	//根据查询条件返回数据
	@RequestMapping("/selectList")
	public List<Student> selectList(){
		QueryWrapper<Student> qw = new QueryWrapper<Student>();
		qw.
			eq("stu_name", "小芳");
		List<Student> list = studentService.selectList(qw);
		for(Student student: list) {
			System.out.println(student);
		}
		return null;
	}
	
	//返回的map键是数据库字段名，值是键对应的值
	@RequestMapping("/selectMaps")
	public void selectMaps() {
		QueryWrapper<Student> qw = new QueryWrapper<Student>();
		qw.
		eq("stu_name", "小芳");			
//		Map<String, Object> map = new HashMap<String, Object>();
		List<Map<String, Object>> list = studentService.selectMaps(qw);
		for(Map<String,Object> map: list) {
			System.out.println(map.get("stu_age"));
		}
		
	}
	
	//返回的是第一个字段的值
	@RequestMapping("/selectObjs")
	public void selectObjs() {
		QueryWrapper<Student> qw = new QueryWrapper<Student>();
		qw.
			eq("stu_name", "小芳");	
		List<Object> list = studentService.selectObjs(qw);
		for(Object object:list) {
			System.out.println(object);
		}
	}
	
	//分页查询
	//new Page<Student>(1,1)第一个参数是查询的是第几页，第二个参数是一页上面显示几条数据
	@RequestMapping("/page")
	public void SelectPage() {
		
		IPage<Student> page = studentService.page(new Page<Student>(1,1), null);
		List<Student> list = page.getRecords();
		for(Student t:list) {
			System.out.println(t);
		}
		
	}
	
	//多表查询 老师为主表和学生表一对多关系
	@RequestMapping("/teaList")
	public void teachers() {
		List<Teacher> list = studentService.teachers("1");
		for(Teacher teacher:list) {
			System.out.println(teacher);
		}
	}
	
}
