package org.yuye.management.service.impl;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.yuye.management.dao.StudentMapper;
import org.yuye.management.dao.TeacherMapper;
import org.yuye.management.pojo.Student;
import org.yuye.management.pojo.Teacher;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

@Service
public class StudentService {

	@Resource
	StudentMapper studentMapper;
	
	@Resource
	TeacherMapper teacherMapper;
	
	
	public void add(Student student) {
		studentMapper.insert(student);
	}
	
	public void deletebyId(Integer id) {
		studentMapper.deleteById(id);
	}
	
	public int deletebymap(Map<String, Object> columnMap) {
		return studentMapper.deleteByMap(columnMap);
	}
	
	public int delete(Wrapper<Student> wrapper) {
		//@param wrapper  查询数据库的条件，实体对象封装操作类（可以为 null）
		return studentMapper.delete(wrapper);
	}
	
	public int deleteBatchIds(List<Integer> idList) {
		return studentMapper.deleteBatchIds(idList);
	}
	
	public int updateById(Student student) {
		return studentMapper.updateById(student);
	}
	
	public int update(Student student,Wrapper<Student> wrapper) {
		return studentMapper.update(student, wrapper);
	}
	
	public Student selectById(int id) {
		return studentMapper.selectById(id);
	}
	
	public List<Student> selectBatchIds(List<Integer> idList){
		return studentMapper.selectBatchIds(idList);
	}
	
	public List<Student> selectByMap(Map<String, Object> map){
		return studentMapper.selectByMap(map);

	}
	
	public Student selectOne(Wrapper<Student> wrapper) {
		return studentMapper.selectOne(wrapper);
	}
	
	public Integer selectCount(Wrapper<Student> wrapper) {
		return studentMapper.selectCount(wrapper);
	}
	
	public List<Student> selectList(Wrapper<Student> wrapper){
		return studentMapper.selectList(wrapper);
	}
	
	public List<Map<String, Object>> selectMaps(Wrapper<Student> wrapper){
		return studentMapper.selectMaps(wrapper);
	}

	public List<Object> selectObjs(Wrapper<Student> wrapper){
		List<Object> list = studentMapper.selectObjs(wrapper);
		return list;
	}
	
	//分页查询
	public IPage<Student> page(Page<Student> p,Wrapper<Student> wrapper){
		return studentMapper.selectPage(p, wrapper);
		
	}
	
	
	//多表查询
	public List<Teacher> teachers(String id){
		
		return teacherMapper.stuList(id);
		}
}
