package org.yuye.management.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.yuye.management.pojo.Student;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface StudentMapper extends BaseMapper<Student>{
	
	
	
	

}
