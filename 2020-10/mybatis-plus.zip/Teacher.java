package org.yuye.management.pojo;

import java.io.Serializable;
import java.util.List;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

@TableName
public class Teacher implements Serializable{
	
	@TableId("tea_id")
	private Integer teaId;
	
	@TableField("tea_name")
	private String teaName;
	
	@TableField("stu_id")
	private Integer stuId;
	
	@TableField(exist = false)
	List<Student> stuList;

	public Integer getTeaId() {
		return teaId;
	}

	public void setTeaId(Integer teaId) {
		this.teaId = teaId;
	}

	public String getTeaName() {
		return teaName;
	}

	public void setTeaName(String teaName) {
		this.teaName = teaName;
	}

	public Integer getStuId() {
		return stuId;
	}

	public void setStuId(Integer stuId) {
		this.stuId = stuId;
	}

	@Override
	public String toString() {
		return "Teacher [teaId=" + teaId + ", teaName=" + teaName + ", stuId=" + stuId + ", stuList=" + stuList + "]";
	}

	

	
	

}
