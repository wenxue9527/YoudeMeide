package org.yuye.management.dao;


import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.yuye.management.pojo.Student;
import org.yuye.management.pojo.Teacher;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface TeacherMapper extends BaseMapper<Teacher>{
	//多表查询 根据id或者全查询
		List<Teacher> stuList(@Param("id")String id);
}
