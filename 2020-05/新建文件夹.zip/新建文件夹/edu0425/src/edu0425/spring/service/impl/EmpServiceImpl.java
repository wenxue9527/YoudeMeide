package edu0425.spring.service.impl;

import java.util.List;

import edu0425.spring.dao.EmpDAO;
import edu0425.spring.dao.impl.DeptDAOImpl;
import edu0425.spring.dao.impl.EmpDAOImpl;
import edu0425.spring.service.EmpService;
import edu0425.spring.vo.EmpInfo;

public class EmpServiceImpl implements EmpService{
	
	private EmpDAO empDAO;

	@Override
	public List<EmpInfo> getEmpList() {
		empDAO = new EmpDAOImpl();
		return empDAO.getEmpList();
	}

	@Override
	public EmpInfo getEmpById(Integer deptno) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Integer getEmpCount() {
		empDAO = new EmpDAOImpl();
	return empDAO.getEmpCount();
	}

}
