package edu0425.spring.service;

import java.util.List;

import edu0425.spring.vo.EmpInfo;


public interface EmpService {
	List<EmpInfo>getEmpList();

    EmpInfo getEmpById(Integer deptno);

    Integer getEmpCount();

}
