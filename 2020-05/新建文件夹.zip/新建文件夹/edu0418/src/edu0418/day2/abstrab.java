package edu0418.day2;

public class abstrab {

}
