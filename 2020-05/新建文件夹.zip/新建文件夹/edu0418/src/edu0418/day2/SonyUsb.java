package edu0418.day2;

import edu0418.day1.Usb;

public class SonyUsb implements Usb {

	@Override
	public void open() {
		// TODO Auto-generated method stub
		System.out.println("Hello Sony");
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub

	}

}
