package edu0418.day1;

public interface Usb {
	//默认是public 
	void open();
	
	void close();
}
