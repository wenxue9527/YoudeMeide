package edu0425.spring.dao;

public interface EmpDAO {

}
